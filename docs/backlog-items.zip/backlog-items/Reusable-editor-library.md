# Make the Markdown parser and editor a reusable library

Investigation, 2026-11-02. The question is whether the code that parses Markdown and renders it in the editor could ship as a library that other developers embed in their own apps to get a Markdown editor or viewer. This note covers what exists today, what stands in the way, a proposed shape and the decisions only the maintainer can make. Nothing has been changed in the code.

## Summary

It is feasible, and the codebase is closer to it than most apps would be. The parsing half is already a SwiftPM library product (`DownwriteCore`). The rendering half (styler, layout manager, text view, overlays) has very few ties to the app, but it lives in the executable target, where nothing is `public`, so nobody else can use it. Splitting it into an `AppKit` library target is a few days of mechanical work plus some API design.

The hard parts are not technical:

1. **The licence.** Everything is GPL-3.0. A GPL library can only be used by GPL apps, which in practice rules out commercial apps and the Mac App Store. If the goal is wide use, the library needs a permissive licence (MIT or Apache-2.0). The git history shows only the maintainer, Claude and the CI bot as authors, so the maintainer can relicense on their own.
2. **The minimum OS.** The package targets macOS 26 only. Nothing in the editor code is gated on macOS 26 (`#available`/`@available` aren't used), so the real minimum may be much lower, but it needs a build to confirm.
3. **The ongoing cost.** Once other people depend on a public API, every refactor of `MarkdownAnalysis`, `MarkdownStyler` or the coordinator becomes either a breaking release or a compatibility shim. That slows down the app work, and the app's history is mostly exactly those refactors (DW-024, DW-025, folding, callouts).

Recommendation: do it in stages inside this repo (below). Start by making the editor a library target that the app itself depends on, which pays off for the app either way. Decide on licence and public release before stage 3.

## What exists today

| Layer | Where | Size | Reusable now? |
| --- | --- | --- | --- |
| Parsing and analysis: `MarkdownAnalyzer` → `MarkdownAnalysis` (spans, markers and reveal ranges, line styles, links, tables, callouts, folds, code blocks, previews), plus formatting commands, list/table/fence editing, TOC, text coding, diffing, themes and palettes, the HTML export | `Sources/DownwriteCore`, library product `DownwriteCore` | about 6,100 lines, 67 public types | Technically yes: it is a library product, pure Swift, built and tested on Linux. But its API was shaped for one caller, and it has never been versioned or documented for outsiders. |
| Rendering and editing: `MarkdownStyler`, `StyleDiff`, `DWLayoutManager` (TextKit 1 custom drawing), `EditorTextView`, `EditorCoordinator` and its extensions (folding, callouts, code copy, images, drag), `TableOverlay`/`TableGrid`, `DiagramOverlay`/`DiagramView` (Mermaid, image and HTML cards), `MermaidService`, `Typography` | `Sources/Downwrite` (executable target) | about 6,000 lines | No. An executable target can't be a dependency, and all its types are `internal`. |
| App shell: `DownwriteApp`, `AppDelegate`, `MarkdownDocument`, settings, `ThemeStore`, TOC sidebar, Keep on Top, print/export controller, self-tests | `Sources/Downwrite` | about 3,400 lines plus export/print (about 500) | Not meant to be reused. |

### How tied is the rendering code to the app?

Less than expected. A grep for app-level dependencies (`UserDefaults`, `Prefs`, `ThemeStore`, `NSDocument`, `AppResources`, `Bundle.module`, `SelfTest`, `TOCModel`) gives:

- **None at all:** `MarkdownStyler`, `StyleDiff`, `DWLayoutManager`, `TableOverlay`, `Previews` (`DiagramOverlay`, `DiagramView`, `ImageLoader`), `EditorFolding`, `EditorCallouts`, `EditorCodeCopy`, `EditorImageDrag`, `ImageIntake`, `CalloutIcon`.
- **`EditorView.swift`** (`EditorView` + `EditorCoordinator`):
  - `EditorSettings` mixes editor settings (font, size, line height, width, spelling) with app concepts (theme ids, `themeRevision`).
  - The palette is resolved through `AppearanceResolver`, which reads `ThemeStore.shared`.
  - The external-change watcher (backlog item 8) asks `NSDocumentController` for the window's document and calls `revert`.
  - The coordinator holds a `TOCModel`, the app's sidebar model.
- **`EditorImages.swift`:** pasting images finds the document's folder and the save-first sheet through `NSDocumentController`/`NSDocument`.
- **`Typography.swift`:** holds `AppearanceResolver` (the `ThemeStore` link above).
- **`Mermaid.swift`:** loads `mermaid-renderer.html` through `AppResources` (main bundle, then `Bundle.module`), and `MermaidService` is a process-wide `shared` singleton.
- **`EditorTextView`/`TableGrid`:** `NSApp.currentEvent`, which is fine in a library.

All of these can be replaced by injected values or callbacks. Many seams already exist for tests (`onAnnouncement`, `imagePasteboard`, `imageClock`, `requestSave`, `promiseStarter`, `codeCopyPasteboard`, and others), and they are close to what an embedding app would want.

## Obstacles and risks

### Licence (the deciding factor)

GPL-3.0 (`LICENSE`) applies to the whole repo. Under GPL, any app that links the library must itself be distributed under GPL. The Mac App Store's terms are widely considered incompatible with GPL. So a GPL library would reach only open-source GPL apps, a small audience. The options:

- **Keep GPL.** Simple, no change, small audience. The app stays protected from closed forks.
- **Relicense only the library targets as MIT or Apache-2.0**, and keep the app GPL. This is the usual split and makes the library usable anywhere. The cost is that someone could build a closed competitor on the editor.
- **LGPL.** It is awkward in Swift: SwiftPM links statically by default, and LGPL's relinking requirement then becomes a burden for consumers. Not recommended.
- **Dual licence** (GPL + commercial). It gives control and possible income, but it is a business to run.

Dependencies are not a problem for any of these: swift-markdown is Apache-2.0 (with cmark-gfm, BSD-2) and Mermaid is MIT. `THIRD-PARTY-NOTICES.md` and `LicenseTests` would need a library version.

### Platforms

- `platforms: [.macOS("26.0")]` would force every consumer onto macOS 26. Before publishing, find the real minimum by lowering it and building (CI runs `macos-26`; a lower-target build job would be needed). `WKWebView` config, SF Symbols in `CalloutIcon`, `.inspector` (app only) and SwiftUI APIs in the wrapper are the likely limits.
- **No iOS.** The editor is AppKit and TextKit 1 (`NSTextView`, `NSLayoutManager`). UIKit has TextKit 1 too (`UITextView` with an explicit `NSLayoutManager`), and the styler's attribute logic would mostly carry over, but the text view, drawing, overlays, mouse/keyboard handling and drag/drop would need a port. That is a separate project of similar size to the editor itself. `DownwriteCore` already works on iOS (and Linux) as it stands.

### API design and stability

- The public Core types expose internals that were never meant as a contract: `StyleFlags` is a raw `UInt32` bit set that is now full (the next flag widens it to `UInt64`, which is a breaking change), the reveal rule, `FoldState`, `TableTails` passes. A library would need a smaller, intentional surface (or would have to accept frequent major versions).
- The app's tests reach internals with `@testable import` (30 files on the app target, 27 on Core). That keeps working, but it means nothing currently checks that the public API alone is enough to build an editor. The app should use only the public API of the editor library, so the app becomes the proof.
- Swift language mode is v5 to avoid strict concurrency. Consumers in Swift 6 mode can still link it, but public types need correct `@MainActor` and `Sendable` annotations or they get warnings and errors at the call sites.
- `swift-markdown` is pinned `upToNextMinor(from: "0.9.0")`. A library with a tight pin blocks consumers who also use swift-markdown. It would need a wider range, and tests against both ends of it.
- Semantic versioning, tags, a changelog and DocC documentation become required.

### Weight

The app's "keep it light" rule carries over well, with one exception: `mermaid.min.js` is 3.4 MB. A library should make diagrams optional (a separate product or a SwiftPM trait), so an app that doesn't need diagrams doesn't ship the file or the hidden `WKWebView`.

### "Viewer" means two things

- **A read-only rendered view inside the editor's look** (syntax hidden everywhere, no caret). This is not supported yet: nothing sets `isEditable`, and reveal is driven by the selection. It would need a "never reveal" mode, read-only text-view handling, and turning off the editing-only features (folding clicks, code copy stays, checkbox clicks optional). That's a small feature, but it has to be designed and tested.
- **A rendered document page.** This already exists: `DocumentHTML.prepare`/`assemble` (Core) produces a sanitised, self-contained, CSP-protected HTML page from Markdown, for a `WKWebView` or for export. It is probably the quickest useful thing to offer as a "viewer", and it works on iOS too.

### Maintenance

Today the test suite guards behaviour through the app (unit tests on a real `NSTextView` plus the real-app e2e). A library would also need its own example app and CI on the supported OS range, and issues from outside users would compete for time with the backlog.

## Proposed shape

One repository, several products:

| Product | Contents | Platforms |
| --- | --- | --- |
| `DownwriteMarkdown` (today `DownwriteCore`, perhaps renamed) | Analysis, editing commands (`Formatter`, `ListEditing`, `TableFormatter`, `FenceEditing`), TOC, folding state, palettes and themes, HTML export | macOS, iOS, Linux |
| `DownwriteEditor` | `MarkdownTextView` (an `NSScrollView`/`NSTextView` pair from `EditorTextView.make`), `MarkdownEditor` (SwiftUI wrapper, today `EditorView`), styler, layout manager, table grids, image and HTML cards | macOS |
| `DownwriteDiagrams` (optional) | `MermaidService` and the bundled Mermaid, plugged into `DownwriteEditor` through a renderer protocol | macOS |
| `Downwrite` app | Everything else, depending only on the public API of the above | macOS |

The public editor API would be small and injected rather than global:

- `MarkdownEditorConfiguration`: font, size, line height, column width, spell check, light/dark `Palette` (instead of theme ids and `ThemeStore`), feature switches (folding, tables as grids, callouts, previews, read-only).
- A delegate or closures for what the host owns: base URL for relative images, opening links, image paste/drop destination (instead of `NSDocumentController`), save-before-paste, announcements, headings changed (instead of `TOCModel`).
- Commands: apply a `FormatCommand`, toggle source view, fold/unfold, reveal heading, copy code block.
- The external-file watcher stays in the app (it's about documents, not editing). The coordinator's `applyExternalText` path becomes a public "replace text, keep caret and scroll" call.

## Staged plan

1. **Make the editor a library target the app uses (no public release).** Move the rendering files from `Sources/Downwrite` into a new `DownwriteEditor` target and replace the five app ties listed above with injected values. Mark the minimum needed as `public`, and move the tests that need `@testable` to the new target. The app gets a cleaner boundary, and it's reversible. A few days of work, mostly mechanical, guarded by the existing test suite and e2e.
2. **Find the real minimum macOS, and add a read-only viewer mode** (each its own ai-sdlc change).
3. **Decide licence and naming, then publish:** DocC documentation, an example app, a small public API for Core (hiding `StyleFlags`, `TableTails` and other internals behind `package` access, which Swift 5.9+ supports across targets in one package), a wider swift-markdown range, Mermaid made optional, semantic versioning starting at 0.x.
4. **Optional later:** a UIKit port of the editor, or an iOS viewer through `DocumentHTML`.

Stage 1 is worth doing even if stages 3 and 4 never happen.

## Similar projects to check before committing

The landscape was not researched for this note. Projects worth comparing before investing in stage 3: MarkdownUI (SwiftUI, read-only rendering), STTextView (TextKit 2 text view for macOS), Runestone (iOS code editor), and the editors in apps that publish their source. Downwrite's selling points against them would be live hidden-syntax editing (Bear-like), table grids, folding, callouts and a Linux-testable core.

## Decisions for the maintainer

1. Is the goal wide adoption (needs a permissive licence for the library) or a GPL library for GPL apps?
2. Scope: an editor, a viewer, or both? Is the HTML viewer (`DocumentHTML`) enough for the viewer case?
3. Minimum macOS the library should support. Is iOS in scope at all?
4. Same repo with several products (recommended) or a separate repository?
5. Should stage 1 become a backlog item (DW-NNN) now?
